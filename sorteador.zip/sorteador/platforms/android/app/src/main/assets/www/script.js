// Variáveis globais que armazenam os números disponíveis e sorteados
let numerosDisponiveis = Array.from({ length: 75 }, (_, i) => i + 1);
let numerosSorteados = [];

// Arrays que armazenam os números por coluna
const colunas = {
    B: Array.from({ length: 15 }, (_, i) => i + 1),
    I: Array.from({ length: 15 }, (_, i) => i + 16),
    N: Array.from({ length: 15 }, (_, i) => i + 31),
    G: Array.from({ length: 15 }, (_, i) => i + 46),
    O: Array.from({ length: 15 }, (_, i) => i + 61)
};

let cartela = [];

// Função para gerar a cartela de Bingo (5x5)
function gerarCartela() {
    cartela = [];

    // Criar as colunas de B, I, N, G, O
    for (let letra in colunas) {
        let coluna = colunas[letra];
        let numerosDaColuna = [];

        // Sorteia 5 números para cada coluna, incluindo a coluna N, que terá "FREE" no centro
        for (let i = 0; i < 5; i++) {
            let indiceAleatorio = Math.floor(Math.random() * coluna.length);
            numerosDaColuna.push(coluna.splice(indiceAleatorio, 1)[0]);
        }

        // Para a coluna N, a célula central será "FREE"
        if (letra === 'N') {
            numerosDaColuna[2] = "FREE";
        }

        cartela.push(numerosDaColuna);
    }

    atualizarCartela();
}

// Função para atualizar a cartela na interface
function atualizarCartela() {
    const cartelaElement = document.getElementById('cartelaBingo');
    cartelaElement.innerHTML = '';

    // Gerar a visualização da cartela com as letras B, I, N, G, O
    const letras = ['B', 'I', 'N', 'G', 'O'];

    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 5; j++) {
            const div = document.createElement('div');
            const numero = cartela[j][i];

            const letraDiv = document.createElement('div');
            letraDiv.classList.add('letra');
            letraDiv.textContent = letras[i];

            const numeroDiv = document.createElement('div');
            numeroDiv.classList.add('numero');
            numeroDiv.textContent = numero === "FREE" ? "FREE" : numero;

            // Se o número foi sorteado, marca ele como preenchido
            if (numerosSorteados.includes(numero)) {
                div.classList.add('preenchido');
            }

            div.appendChild(letraDiv);
            div.appendChild(numeroDiv);
            cartelaElement.appendChild(div);
        }
    }
}

// Função para sortear um número aleatório entre 1 e 75
function sortearNumero() {
    if (numerosDisponiveis.length === 0) {
        alert("Todos os números foram sorteados!");
        document.getElementById('resetButton').style.display = 'inline-block';
        return;
    }

    // Sorteia um número aleatório do array de números disponíveis
    const indiceAleatorio = Math.floor(Math.random() * numerosDisponiveis.length);
    const numero = numerosDisponiveis.splice(indiceAleatorio, 1)[0]; // Remove o número sorteado

    // Adiciona o número sorteado à lista e ordena
    numerosSorteados.push(numero);
    numerosSorteados.sort((a, b) => a - b);

    // Atualiza a interface com o número sorteado
    document.getElementById('numeroSorteado').textContent = `Número Sorteado: ${numero}`;
    atualizarCartela();
}

// Função para reiniciar o jogo
function reiniciarJogo() {
    numerosDisponiveis = Array.from({ length: 75 }, (_, i) => i + 1); // Recria o array com números de 1 a 75
    numerosSorteados = []; // Limpa a lista de números sorteados
    gerarCartela(); // Gera uma nova cartela
    document.getElementById('numeroSorteado').textContent = 'Clique para sortear';
    document.getElementById('resetButton').style.display = 'none'; // Esconde o botão de reiniciar
}

// Adiciona o evento de clique para o botão "Sortear Número"
document.getElementById('sortearButton').addEventListener('click', sortearNumero);

// Adiciona o evento de clique para o botão "Reiniciar Jogo"
document.getElementById('resetButton').addEventListener('click', reiniciarJogo);

// Inicializa a cartela ao carregar a página
window.onload = gerarCartela;
